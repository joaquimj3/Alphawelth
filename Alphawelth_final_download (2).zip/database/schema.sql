-- Users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Wallet table
CREATE TABLE IF NOT EXISTS wallet (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  balance_mzn NUMERIC(18,2) DEFAULT 0,
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  amount_mzn NUMERIC(18,2) NOT NULL,
  type TEXT CHECK (type IN ('deposit','withdraw','invest','return')),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Investments table
CREATE TABLE IF NOT EXISTS investments (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  plan_name TEXT NOT NULL,
  amount_mzn NUMERIC(18,2) NOT NULL,
  status TEXT CHECK (status IN ('active','closed')) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW()
);

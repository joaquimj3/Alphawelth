-- Rates table
CREATE TABLE IF NOT EXISTS rates (
  currency TEXT PRIMARY KEY,
  value NUMERIC(18,6) NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW()
);

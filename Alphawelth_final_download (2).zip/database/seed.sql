-- Seed admin user (Alphawelth initial admin)
-- WARNING: keep these credentials secure. Change password after first login.
INSERT INTO users (email, phone, password_hash, created_at)
VALUES ('joaquimjorgejoaquim55@gmail.com', '864617807', '$2b$12$Urj3yJXiv3LQ1IZF4OjQxu3QKmHa7ukC6td/nSnfKNq09jTRIRyI6', NOW())
RETURNING id;

-- After inserting user, you may want to create a wallet row for them.
-- Replace <ID> with the returned id value (or run a SELECT to find the id).
INSERT INTO wallet (user_id, balance_mzn, updated_at)
VALUES ((SELECT id FROM users WHERE email = 'joaquimjorgejoaquim55@gmail.com'), 0.00, NOW());

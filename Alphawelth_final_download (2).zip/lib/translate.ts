export async function translateText(text: string, targetLang: string) {
  // Placeholder formal automatic translation.
  if (!targetLang || targetLang === 'en') return text;
  // This is a stub. Replace with a real translation API if desired.
  return `[FORMAL ${targetLang.toUpperCase()}] ` + text;
}

import { db } from './db';

export async function updateRates(){
  try {
    const res = await fetch('https://api.exchangerate.host/latest?base=MZN');
    const data = await res.json();
    if(!data || !data.rates) return;
    const rates = data.rates;
    for(const [currency, value] of Object.entries(rates)){
      await db.query(
        `INSERT INTO rates(currency, value, updated_at) VALUES($1,$2,NOW())
         ON CONFLICT (currency) DO UPDATE SET value=$2, updated_at=NOW()`,
        [currency, value]
      );
    }
  } catch(e){
    console.error('Failed to update rates', e);
  }
}

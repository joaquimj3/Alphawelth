import AutoTranslate from '@/app/[lang]/_components/AutoTranslate';
import HeroImage from '@/app/components/HeroImage';
export default function HomePage({ params }: any) {
  const baseTitle = 'Welcome to Alphawelth Premium Investment Platform';
  const baseDescription = 'Manage your investments with safety, clarity, and confidence.';
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <HeroImage src="/images/formatura.jpg" />
      <h1 className="text-4xl font-bold"><AutoTranslate text={baseTitle} lang={params.lang} /></h1>
      <p className="mt-4 text-gray-600"><AutoTranslate text={baseDescription} lang={params.lang} /></p>
    </div>
  );
}

import LanguageSelector from '@/app/components/LanguageSelector';
import { supportedLanguages, defaultLanguage } from '@/i18n/config';

export function generateStaticParams() {
  return supportedLanguages.map(lang => ({ lang }));
}

export default function LangLayout({ children, params }: any) {
  const currentLang = supportedLanguages.includes(params.lang) ? params.lang : defaultLanguage;
  return (
    <html lang={currentLang}>
      <body>
        <div className="fixed top-4 right-4 z-50"><LanguageSelector /></div>
        {children}
      </body>
    </html>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { translateText } from '@/lib/translate';

export default function AutoTranslate({ text, lang }: { text: string; lang: string }) {
  const [t, setT] = useState(text);
  useEffect(() => {
    let mounted = true;
    translateText(text, lang).then(res => { if (mounted) setT(res); });
    return () => { mounted = false; };
  }, [text, lang]);
  return <>{t}</>;
}

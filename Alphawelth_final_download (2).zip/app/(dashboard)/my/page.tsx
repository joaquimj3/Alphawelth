export default function MyPage(){
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">My Account</h1>
      <div className="bg-white shadow rounded-2xl p-6">
        <h2 className="text-xl font-semibold mb-2">Profile</h2>
        <p className="text-gray-600 mb-4">View and manage your account information.</p>
        <button className="bg-gray-800 text-white px-4 py-2 rounded-xl">Edit Profile</button>
      </div>
      <div className="bg-white shadow rounded-2xl p-6">
        <h2 className="text-xl font-semibold mb-2">Wallet Balance</h2>
        <p className="text-gray-600 mb-4">Your funds in MZN.</p>
        <div className="text-2xl font-bold">0.00 MZN</div>
        <div className="flex gap-3 mt-4">
          <button className="bg-green-600 text-white px-4 py-2 rounded-xl">Deposit</button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-xl">Withdraw</button>
        </div>
      </div>
    </div>
  );
}

export default function DashboardLayout({ children }: any) {
  return (
    <div className="flex min-h-screen">
      <nav className="w-64 bg-white shadow p-4">
        <a className="block font-semibold mb-3" href="/en/home">Home</a>
        <a className="block font-semibold mb-3" href="/en/alphaprans">AlphaPrans</a>
        <a className="block font-semibold mb-3" href="/en/team">Team</a>
        <a className="block font-semibold mb-3" href="/en/my">My</a>
      </nav>
      <main className="flex-1 p-8 bg-gray-50">{children}</main>
    </div>
  );
}

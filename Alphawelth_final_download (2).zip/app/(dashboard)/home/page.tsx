export default function DashboardHome(){
  return <h1 className="text-3xl font-bold">Dashboard Home</h1>;
}

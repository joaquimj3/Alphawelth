import TeamImage from '@/app/components/TeamImage';
export default function TeamPage(){
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Our Team</h1>
      <p className="text-gray-600">Meet the professional minds behind Alphawelth.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {['CEO','CTO','CFO'].map((r,i)=>(
          <div key={i} className="bg-white shadow rounded-2xl p-6 text-center">
            <TeamImage src="/images/formatura.jpg" />
            <h2 className="text-xl font-semibold">{r}</h2>
            <p className="text-gray-500 mt-2">Professional and experienced.</p>
          </div>
        ))}
      </div>
    </div>
  );
}

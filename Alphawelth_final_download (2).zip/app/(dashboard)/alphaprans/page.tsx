export default function AlphaPransPage(){
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">AlphaPrans Investment Plans</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[{name:'Starter',percent:5,period:'30 days'},{name:'Growth',percent:12,period:'90 days'},{name:'Premium',percent:20,period:'180 days'}].map((p,i)=>(
          <div key={i} className="bg-white shadow rounded-2xl p-6 border">
            <h2 className="text-xl font-semibold mb-2">{p.name}</h2>
            <p className="text-gray-600 mb-2">Return: {p.percent}% · {p.period}</p>
            <button className="bg-black text-white px-4 py-2 rounded-xl">Invest Now</button>
          </div>
        ))}
      </div>
    </div>
  );
}

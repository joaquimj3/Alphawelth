export default function Page() {
  return (
    <main className="p-8 max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold">Alphawelth</h1>
      <p className="mt-2 text-gray-600">Premium investment platform — sign in to manage investments.</p>
      <div className="mt-6">
        <a href="/en/home" className="px-4 py-2 bg-black text-white rounded">Open Site</a>
      </div>
    </main>
  );
}

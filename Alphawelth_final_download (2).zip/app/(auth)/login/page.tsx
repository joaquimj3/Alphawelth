'use client';
import { useState } from 'react';

export default function Login() {
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [msg,setMsg] = useState('');

  async function onSubmit(e:any){
    e.preventDefault();
    const res = await fetch('/api/auth/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})});
    const data = await res.json();
    if (data.token) setMsg('Login successful');
    else setMsg(data.error || 'Login failed');
  }

  return (
    <div className="p-8 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Login</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="w-full border p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="w-full border p-2" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full bg-black text-white p-2 rounded">Login</button>
      </form>
      <div className="mt-3 text-sm text-gray-600">{msg}</div>
    </div>
  );
}

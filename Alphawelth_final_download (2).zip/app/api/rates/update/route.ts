import { NextResponse } from 'next/server';
import { updateRates } from '@/lib/fetchRates';

export async function GET(){
  await updateRates();
  return NextResponse.json({ success: true, message: 'Rates updated' });
}

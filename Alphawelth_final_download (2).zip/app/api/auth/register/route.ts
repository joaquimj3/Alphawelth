import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from '@/lib/db';

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  phone: z.string().optional()
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = schema.parse(body);
    const hashed = await bcrypt.hash(parsed.password, 10);

    const query = 'INSERT INTO users(email, phone, password_hash) VALUES($1,$2,$3) RETURNING id';
    const values = [parsed.email, parsed.phone || null, hashed];
    const result = await db.query(query, values);

    return NextResponse.json({ success: true, id: result.rows[0].id });
  } catch (err:any) {
    return NextResponse.json({ error: err.message || 'Invalid data' }, { status: 400 });
  }
}

export default function HeroImage({ src }: { src: string }) {
  return (
    <div className="w-full h-64 rounded-2xl overflow-hidden shadow mb-6">
      <img src={src} alt="Hero" className="w-full h-full object-cover" />
    </div>
  );
}

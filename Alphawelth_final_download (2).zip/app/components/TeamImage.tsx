export default function TeamImage({ src }: { src: string }) {
  return (
    <img src={src} alt="Team" className="w-32 h-32 object-cover rounded-full shadow mx-auto mb-4" />
  );
}

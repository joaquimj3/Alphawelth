'use client';
import { useRouter, usePathname } from 'next/navigation';
import { supportedLanguages } from '@/i18n/config';

export default function LanguageSelector(){
  const router = useRouter();
  const pathname = usePathname() || '/';
  const changeLang = (lang:string) => {
    // prepend lang to path, remove previous lang if present
    const newPath = '/' + lang + pathname.replace(/^\/[a-zA-Z-]{2}/,'');
    router.push(newPath);
  };
  return (
    <div className="flex gap-2 p-2 bg-white rounded shadow">
      {supportedLanguages.map(l=>(
        <button key={l} className="px-2 py-1 border rounded" onClick={()=>changeLang(l)}>{l.toUpperCase()}</button>
      ))}
    </div>
  );
}

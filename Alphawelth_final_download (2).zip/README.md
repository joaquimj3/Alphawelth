# Alphawelth - Investment Platform

This ZIP contains a ready scaffold for the Alphawelth platform (Next.js appDir). Follow the README sections below to finish setup.

## What is included
- Full Next.js app structure (app directory)
- Auth API (register/login)
- PostgreSQL DB helpers and SQL schema
- Currency rates updater using ExchangeRate.host (free)
- Multi-language route scaffolding with automatic formal translations
- Dashboard pages: Home, AlphaPrans, Team, My
- Simple components and styles (Tailwind)

## Quick steps
1. Unzip and open the project
2. Install dependencies: `npm install`
3. Create a database and set `DATABASE_URL` in `.env.local`
4. Set `JWT_SECRET` in `.env.local`
5. Run SQL schemas:
   - `psql $DATABASE_URL -f database/schema.sql`
   - `psql $DATABASE_URL -f database/update_rates.sql`
6. Run dev: `npm run dev`

## Notes
- Put your formatura image at `public/images/formatura.jpg`
- Translation is a placeholder (replace with real translation API if needed)
- This scaffold is ready to push to GitHub and deploy to Render


---
## Deploy to Render (exact steps)

1. Push the project to a GitHub repository.
2. On Render, create a new **Web Service** and connect your GitHub repo.
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
3. Create a **PostgreSQL** database on Render and copy the DATABASE_URL.
4. In the Web Service settings -> Environment, add:
   - `DATABASE_URL` = your_render_db_url
   - `JWT_SECRET` = a long random string (ex: use `openssl rand -hex 32`)
   - `NODE_ENV` = production
5. After the DB is provisioned, run the SQL files once (you can use psql from your machine or the Render console):
   - `psql $DATABASE_URL -f database/schema.sql`
   - `psql $DATABASE_URL -f database/update_rates.sql`
   - `psql $DATABASE_URL -f database/seed.sql`  -- This will insert the admin user.
6. Configure a cron job on Render (Scheduled Job) to call the rates updater every hour:
   - URL: `https://<your-render-app>/api/rates/update`
   - Frequency: `Hourly` (or every 30 minutes if you prefer)
7. Upload your formatura image to `public/images/formatura.jpg` via GitHub or Render files.

## Important security steps (do immediately after deploy)
- Login with the admin credentials (from ADMIN_CREDENTIALS.txt) and change the password.
- Remove `ADMIN_CREDENTIALS.txt` from the GitHub repository if you pushed it publicly.
- Store `JWT_SECRET` securely and rotate if leaked.

---

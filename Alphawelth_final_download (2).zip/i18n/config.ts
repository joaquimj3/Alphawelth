export const supportedLanguages = [
  'en','pt','es','fr','de','it','zh','ja','ru','ar','hi'
];
export const defaultLanguage = 'en';
